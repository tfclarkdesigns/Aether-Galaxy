# 2025-11-14
- uploaded The Kols Files, Chapter 3 in Markdown and PDF
- added The Kols Files and this file to GitHub Pages site.
- Cleaned up GitHub Pages site formatting and made all file names stable 
- changed this file's name for compatibility

---

# 2025-11-13

## AGFG:  

### r8 updates:

- Tens of thousands of *ecologically prime* inhabited planets.
- Weros "smaller sectors" -> "most sectors"

## Astrogation Holocodex  

### r2 updates

- Toned down the em dashes to only quotes

## Field Catalog of Weros

### r3 updates

- Remove ship cost multiplier

## The Will of Order  

### r2 updates

- Block quote second quote in Law of the Strong

## Archives of the Lost

### r2 updates

- Fix metadata table  
- Put release number and license at bottom  
- Add slogan  
- Formatted attribution like The Kols Files  

---

- Fixed homepage thumbnail and link path issues

- Updated GitHub Pages site layout

- Published Aether Galaxy thumbnail artwork

- Preparing for Kols Files Chapter 3 release